// A surface keeps its logical resources while the browser replaces its GL context.
export function createWebGlRecovery(gl,canvas,{suspend,resume,error},initialize) {
  const resources=new Set(),waiting=new Set();
  let state='ready',generation=0,contextGeneration=0,failure;
  const aborted=()=>new DOMException('The WebGL surface is closed','AbortError');
  const suspended=()=>state!=='ready'||gl.isContextLost();
  const settle=(method,value)=>{
    for(const waiter of waiting) waiter[method](value);
    waiting.clear();
  };
  function ready(signal) {
    if(signal?.aborted) return Promise.reject(signal.reason);
    if(state==='closed') return Promise.reject(aborted());
    if(state==='failed') return Promise.reject(failure);
    if(!suspended()) return Promise.resolve();
    return new Promise((resolve,reject)=>{
      const finish=(settle,value)=>{waiting.delete(waiter);signal?.removeEventListener('abort',abort);settle(value);};
      const waiter={resolve:value=>finish(resolve,value),reject:value=>finish(reject,value)};
      const abort=()=>waiter.reject(signal.reason);
      waiting.add(waiter);signal?.addEventListener('abort',abort,{once:true});
    });
  }
  function lost(event) {
    event.preventDefault();generation++;state='lost';suspend();
  }
  async function restored() {
    const version=++generation;
    contextGeneration++;
    state='restoring';
    const current=()=>generation===version&&!gl.isContextLost();
    try {
      initialize();
      for(const resource of resources) {
        await resource.restore(current);
        if(!current()) return;
      }
      if(!current()) return;
      state='ready';resume();settle('resolve');
    } catch(cause) {
      // A second loss invalidates this restoration, just like an interrupted draw.
      if(!current()) return;
      failure=cause;state='failed';settle('reject',cause);error(cause);
    }
  }
  canvas.addEventListener('webglcontextlost',lost);
  canvas.addEventListener('webglcontextrestored',restored);
  return {
    get suspended() {return suspended();},
    get contextGeneration() {return contextGeneration;},
    ready,
    track(resource) {
      if(state==='closed') throw aborted();
      resources.add(resource);return ()=>resources.delete(resource);
    },
    async create(initialize,signal) {
      for(;;) {
        await ready(signal);const version=generation;
        try {
          const resource=await initialize();
          if(version===generation&&!suspended()&&!signal?.aborted) return resource;
          resource.close();
        } catch(cause) {
          if(version===generation&&!gl.isContextLost()) throw cause;
        }
      }
    },
    close() {
      if(state==='closed') throw aborted();
      generation++;state='closed';
      canvas.removeEventListener('webglcontextlost',lost);
      canvas.removeEventListener('webglcontextrestored',restored);
      settle('reject',aborted());
      for(const resource of resources) resource.destroy();
      resources.clear();
    }
  };
}
