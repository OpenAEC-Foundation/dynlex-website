import {createWebGlShader} from './shader-webgl.js';
import {packShaderDraws} from './shader-streams.js';

// Retain the latest authored data, never a history of frame uploads or GL calls.
export async function createRestorableWebGlShader(surface,descriptor,signal) {
  descriptor=structuredClone(descriptor);
  const {gl,recovery}=surface;
  const target=record=>({texture:record.storage,width:record.width,height:record.height,colored:true});
  const uploads=new Map(),executions=new Map();
  for(const [index,pass] of descriptor.passes.entries()) uploads.set(JSON.stringify(['draws',index]),{
    method:'draws',args:[index,packShaderDraws(pass.draws)]
  });
  const capture=index=>executions.set(index,new Map([...uploads].filter(([,record])=>
    record.method==='imageBytes'||(record.method!=='passEnabled'&&record.args[0]===index))));
  const create=rendered=>{
    const generation=recovery.contextGeneration;
    return createWebGlShader(gl,descriptor,target,{rendered,
      current:()=>generation===recovery.contextGeneration&&!gl.isContextLost()});
  };
  let renderer=await recovery.create(()=>create(capture),signal);
  let closed=false,frame=null,output=null;
  const active=()=>{if(closed) throw new Error('The shader program is closed');};
  const remember=(method,keys,args)=>{
    active();
    renderer[method](...args);
    uploads.set(JSON.stringify([method,...keys]),{method,args:args.map(value=>ArrayBuffer.isView(value)?value.slice():value)});
  };
  const update=value=>{
    if(output===null) output=value;
    else Object.assign(output,value);
    return output;
  };
  const untrack=recovery.track({
    async restore(current) {
      let recording=false;
      const next=await create(index=>{if(recording) capture(index);});
      try {
        if(!current()||closed) {next.close();return;}
        if(frame!==null) next.resize(...frame);
        // Initialize every pass's required inputs before replaying completed work.
        for(const {method,args} of uploads.values()) if(method!=='imageBytes') next[method](...args);
        for(let index=0;index<descriptor.passes.length;index++) next.passEnabled(index,false);
        for(let index=0;index<descriptor.passes.length;index++) {
          const execution=executions.get(index);
          if(execution===undefined) continue;
          for(const {method,args} of execution.values()) next[method](...args);
          next.passEnabled(index,true);update(next.render(...frame));next.passEnabled(index,false);
        }
        for(let index=0;index<descriptor.passes.length;index++) next.passEnabled(index,true);
        for(const {method,args} of uploads.values()) next[method](...args);
      } catch(error) {next.close();throw error;}
      renderer.close();renderer=next;recording=true;
    },
    destroy() {result.close();}
  });
  const result={
    vertexBuffer(index,slot,data) {remember('vertexBuffer',[index,slot],[index,slot,data]);},
    indexBuffer(index,data) {remember('indexBuffer',[index],[index,data]);},
    draws(index,data) {remember('draws',[index],[index,data]);},
    passEnabled(index,enabled) {remember('passEnabled',[index],[index,enabled]);},
    imageBytes(name,level,layer,bytes) {remember('imageBytes',[name,level,layer],[name,level,layer,bytes]);},
    uniformBuffer(index,group,binding,scalar,rows,columns,bytes) {
      remember('uniformBuffer',[index,group,binding],[index,group,binding,scalar,rows,columns,bytes]);
    },
    bufferBytes(index,slot) {active();return renderer.bufferBytes(index,slot);},
    bufferRecords(index,slot) {active();return renderer.bufferRecords(index,slot);},
    indexCount(index) {active();return renderer.indexCount(index);},
    render(width,height) {
      active();
      if(frame!==null&&(frame[0]!==width||frame[1]!==height)) {
        const framed=name=>descriptor.assets.find(asset=>asset.name===name).size.kind==='frame';
        for(const [index,pass] of descriptor.passes.entries()) {
          if((pass.color!==null&&framed(pass.color.view.image))||(pass.depth!==null&&framed(pass.depth.view.image))) executions.delete(index);
        }
        for(const [key,record] of uploads) if(record.method==='imageBytes'&&framed(record.args[0])) uploads.delete(key);
      }
      const value=update(renderer.render(width,height));frame=[width,height];return value;
    },
    close() {active();closed=true;untrack();uploads.clear();executions.clear();renderer.close();output=null;frame=null;}
  };
  return result;
}
